Please note that all sounds in this pack are created and published by Particle.

In whatever circumstances it is used, please provide credits, or else they are considered stolen.


Thank you

- Particle